package com.example.empresa.repositories;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.empresa.models.Projeto;

public interface ProjetoRepository extends JpaRepository<Projeto, Integer> {
    Projeto findById(Integer id);
    // No repositório ProjetoRepository crie um método que passamos o ID do projeto
    // e ele retornará os dados do projeto e a lista de funcionários vinculados
    // aquele projeto.

    List<Projeto> findByDates(LocalDate dataInicio, LocalDate dataFim);
    // No repositório ProjetoRepository crie um método que passamos uma data de
    // início e fim e é retornado todos os projetos que iniciam entre as datas
    // informadas
}
