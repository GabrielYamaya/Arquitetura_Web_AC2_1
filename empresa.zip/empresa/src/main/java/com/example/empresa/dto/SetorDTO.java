package com.example.empresa.dto;

import java.util.List;
import com.example.empresa.models.Funcionario;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SetorDTO {
    private Integer id;
    private String nome;
    private List<Funcionario> funcionarios;
}
