package com.example.empresa.dto;

import java.util.List;
import com.example.empresa.models.Funcionario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsereSetorDTO {
    private Integer id;
    private String nome;
    private List<Funcionario> funcionarios;
}
