package com.example.empresa.services;

import org.hibernate.mapping.List;
import org.springframework.stereotype.Service;

import com.example.empresa.dto.InsereSetorDTO;
import com.example.empresa.dto.SetorDTO;
import com.example.empresa.exceptions.RegraNegocioException;
import com.example.empresa.models.Funcionario;
import com.example.empresa.models.Setor;
import com.example.empresa.repositories.FuncionarioRepository;
import com.example.empresa.repositories.SetorRepository;

@Service
public class SetorServiceImpl implements SetorService {
    private SetorRepository setorRepository;
    private FuncionarioRepository funcionarioRepository;

    public SetorServiceImpl(SetorRepository setorRepository, FuncionarioRepository funcionarioRepository) {
        this.setorRepository = setorRepository;
        this.funcionarioRepository = funcionarioRepository;
    }

    @Override
    public Setor inserir(InsereSetorDTO setorDTO) {

        Setor setorObj = new Setor();
        setorObj.setId(setorDTO.getId());
        setorObj.setNome(setorDTO.getNome());
        setorObj.setFuncionarios(setorDTO.getFuncionarios());

        return setorRepository.save(setorObj);
    }

    @Override
    public SetorDTO buscarPorId(Integer id) {
        Setor setor = setorRepository.findById(id).orElseThrow(() -> new RegraNegocioException("Curso não encontrado"));

        return SetorDTO.builder()
                .id(setor.getId())
                .nome(setor.getNome())
                .funcionarios(setor.getFuncionarios())
                .build();
    }

    @Override
    public void excluirPorId(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'excluirPorId'");
    }

    @Override
    public void editarPorId(Integer id, Setor setor) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'editarPorId'");
    }

    @Override
    public void editarPorId(Integer id, SetorDTO setorDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'editarPorId'");
    }

}
