package com.example.empresa.services;

import java.util.List;

import com.example.empresa.dto.InsereFuncionarioDTO;
import com.example.empresa.models.Funcionario;
import com.example.empresa.models.Projeto;

public interface FuncionarioService {
    Funcionario inserir(InsereFuncionarioDTO funcionarioDTO);

    List<Projeto> buscarProjetosPorfuncionarioId(Integer id);

    void excluirPorId(Integer id);

    void editarPorId(Integer id, Funcionario funcionario);
}
