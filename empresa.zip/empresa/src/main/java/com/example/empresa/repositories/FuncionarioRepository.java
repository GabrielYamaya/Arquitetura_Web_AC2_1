package com.example.empresa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.empresa.models.Funcionario;
import com.example.empresa.models.Projeto;

public interface FuncionarioRepository extends JpaRepository<Funcionario, Integer> {
    List<Projeto> findProjetoByFuncionarioId(Integer id);
    // No repositório FuncionarioRepository crie um método que passamos o ID do
    // funcionário e é retornado todos os projetos em que ele está vinculado.
}
