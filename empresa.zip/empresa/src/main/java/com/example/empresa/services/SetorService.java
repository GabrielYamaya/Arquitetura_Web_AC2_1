package com.example.empresa.services;

import com.example.empresa.dto.InsereSetorDTO;
import com.example.empresa.dto.SetorDTO;
import com.example.empresa.models.Setor;

public interface SetorService {
    Setor inserir(InsereSetorDTO setorDTO);

    SetorDTO buscarPorId(Integer id);

    void excluirPorId(Integer id);

    void editarPorId(Integer id, SetorDTO setorDTO);
}