package com.example.empresa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.empresa.dto.InsereFuncionarioDTO;
import com.example.empresa.models.Projeto;
import com.example.empresa.services.FuncionarioService;

@RestController
@RequestMapping("/api/empresa")
public class FuncionarioController {
    @Autowired
    private FuncionarioService funcionarioService;

    public void postFuncionario(@RequestBody InsereFuncionarioDTO funcionario) {
        funcionarioService.inserir(funcionario);
    }
    // adicionar(funcionario : FuncionarioDTO):void

    public List<Projeto> getProjetosPorFuncionarioId(Integer id) {
        return funcionarioService.buscarProjetosPorfuncionarioId(id);
    }
    // buscarProjetos(idFuncionario : Integer) : List<DadosProjetoDTO>
}
