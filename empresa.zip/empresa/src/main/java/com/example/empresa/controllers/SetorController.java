package com.example.empresa.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.empresa.dto.InsereSetorDTO;
import com.example.empresa.models.Projeto;
import com.example.empresa.models.Setor;
import com.example.empresa.services.SetorService;

@RestController
@RequestMapping("/api/empresa")
public class SetorController {
    @Autowired
    private SetorService setorService;

    @PostMapping()
    @ResponseStatus(HttpStatus.CREATED)
    public void postSetor(@RequestBody InsereSetorDTO setor) {
        setorService.inserir(setor);
    }
    // adicionar(setor : SetorDTO):void

    @GetMapping("{id}")
    public Setor getSetorPorId(Integer id) {
        return setorService.buscarPorId(id);
    }
    // buscarSetorPorId(idSetor : Integer) : DadosSetorDTO

}
