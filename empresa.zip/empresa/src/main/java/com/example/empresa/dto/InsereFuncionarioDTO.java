package com.example.empresa.dto;

import com.example.empresa.models.Setor;
import java.util.List;
import com.example.empresa.models.Projeto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsereFuncionarioDTO {
    private Integer id;
    private String nome;
    private Setor setor;
    private List<Projeto> projetos;
}
