package com.example.empresa.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.empresa.models.Setor;

public interface SetorRepository extends JpaRepository<Setor, Integer> {
    List<Setor> listAllSectors();
    // No repositório SetorRepository crie um método que lista todos os setores com
    // os funcionários vinculados a cada setor.
}
