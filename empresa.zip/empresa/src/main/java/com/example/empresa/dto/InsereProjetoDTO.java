package com.example.empresa.dto;

import java.util.List;
import java.time.LocalDate;
import com.example.empresa.models.Funcionario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InsereProjetoDTO {
    private Integer id;
    private String nome;
    private LocalDate dataInicio;
    private LocalDate dataFim;
    private List<Funcionario> funcionarios;
}
