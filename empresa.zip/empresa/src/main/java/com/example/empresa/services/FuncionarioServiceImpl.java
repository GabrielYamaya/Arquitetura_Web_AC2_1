package com.example.empresa.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.empresa.dto.InsereFuncionarioDTO;
import com.example.empresa.models.Funcionario;
import com.example.empresa.models.Projeto;
import com.example.empresa.repositories.FuncionarioRepository;
import com.example.empresa.repositories.ProjetoRepository;

@Service
public class FuncionarioServiceImpl implements FuncionarioService {
    private FuncionarioRepository funcionarioRepository;
    private List<Projeto> projetos;

    public FuncionarioServiceImpl(FuncionarioRepository funcionarioRepository, List<Projeto> projetos) {
        this.funcionarioRepository = funcionarioRepository;
        this.projetos = projetos;
    }

    @Override
    public Funcionario inserir(InsereFuncionarioDTO funcionarioDTO) {

    }

    @Override
    public List<Projeto> buscarProjetosPorfuncionarioId(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'buscarProjetosPorfuncionarioId'");
    }

    @Override
    public void excluirPorId(Integer id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'excluirPorId'");
    }

    @Override
    public void editarPorId(Integer id, Funcionario funcionario) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'editarPorId'");
    }

}
