package com.example.empresa.services;

import com.example.empresa.dto.InsereProjetoDTO;
import com.example.empresa.models.Projeto;

public interface ProjetoService {
    Projeto inserir(InsereProjetoDTO projetoDTO);

    Projeto buscarPorId(Integer id);

    void excluirPorId(Integer id);

    void editarPorId(Integer id, Projeto projeto);
}
