package com.example.empresa.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.empresa.dto.InsereProjetoDTO;
import com.example.empresa.models.Funcionario;
import com.example.empresa.models.Projeto;
import com.example.empresa.services.ProjetoService;

@RestController
@RequestMapping("/api/empresa")
public class ProjetoController {
    @Autowired
    private ProjetoService projetoService;

    @PostMapping()
    @ResponseStatus(HttpStatus.CREATED)
    public void postProjeto(@RequestBody InsereProjetoDTO projeto) {
        projetoService.inserir(projeto);
    }
    // adicionar(projeto : ProjetoDTO) : void

    @GetMapping("{id}")
    public Projeto getProjetoPorId(Integer id) {
        return projetoService.buscarPorId(id);
    }
    // buscarProjetoPorId(id : Integer): DadosProjetoDTO /* retorna com a lista de
    // funcionários */

    public void vincularFuncionario() {

    }
    // vincularFuncionario(idProjeto : Integer, idFuncionario : Integer) : void

}
